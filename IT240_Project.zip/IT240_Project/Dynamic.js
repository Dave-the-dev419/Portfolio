var navButton = getDocumentByElement("button");
/* Function change() {
  var nothing = alert("works!");
}*/